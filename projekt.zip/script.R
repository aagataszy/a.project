read.csv(file = "data/inflammation-01.csv", header = FALSE)

